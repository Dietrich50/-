﻿CREATE TABLE Crackers (
    CookieId INT PRIMARY KEY IDENTITY,
    Name VARCHAR(150) NOT NULL, 
    OrderDate INT NOT NULL,
    SaleDate INT NULL,
    Category VARCHAR(50) NOT NULL,
    Status VARCHAR(50) NOT NULL
);
