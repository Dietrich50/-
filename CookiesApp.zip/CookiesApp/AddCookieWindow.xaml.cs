﻿using System.Linq;
using System.Windows;
using CookiesApp.Interfaces;
using CookiesApp.Models;

namespace CookiesApp
{
    /// <summary>
    /// Логика взаимодействия для AddCookieWindow.xaml
    /// </summary>
    public partial class AddCookieWindow : Window
    {
        /// <summary>
        /// Список вида печенья 
        /// </summary>
        private static readonly string[] Categories = { "With sugar", "Without sugar" };
        /// <summary>
        /// Статус печенья
        /// </summary>
        private static readonly string[] Statuses = { "Available", "Sold", "Restocking" }; 
        /// <summary>
        ///  Поле хранит идентификатор товара
        /// </summary>
        private int _id;
        public AddCookieWindow()
        {
            InitializeComponent();
            // Передаем допустимые значения
            cbCategory.ItemsSource = Categories;
            cbStatus.ItemsSource = Statuses;
            // Задаем начальное значение
            cbCategory.SelectedIndex = 0;
            cbStatus.SelectedIndex = 0;
        }

        private void BtnCancel_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }

        private void BtnSave_Click(object sender, RoutedEventArgs e)
        {
            int? sale = null;

            if (string.IsNullOrEmpty(tbName.Text))
            {
                MessageBox.Show("Поле наименование не может быть пустым", "Проверка");
                return;
            }            

            if (!int.TryParse(tbOrderDate.Text, out int order))
            {
                MessageBox.Show("Дата заказа должна быть целым числом", "Проверка");
                return;
            }

            if (!string.IsNullOrEmpty(tbSaleDate.Text))
            {
                int intSale;
                if (!int.TryParse(tbSaleDate.Text, out intSale))
                {
                    MessageBox.Show("Дата продажи должна быть целым числом", "Проверка");
                    return;
                }

                if (intSale < order)
                {
                    MessageBox.Show("Дата продажи должны быть больше даты заказа", "Проверка");
                    return;
                }
                sale = intSale;
            }

            // Создаем объект для передачи данных
            CookieDto cookie = new CookieDto()
            {
                // Заполняем объект данными
                Name = tbName.Text,                
                OrderDate = order,
                SaleDate = sale,
                Category = cbCategory.SelectedItem.ToString(),
                Status = cbStatus.SelectedItem.ToString()
            };
            // Именно тут запрашиваем реализованную раннее задачу по работе с товарами 
            ICookieProcess cookieProcess = ProcessFactory.GetCookieProcess();
            // если это новый объект -  сохраняем его
            if (_id == 0)
            {
                // Сохраняем печенье 
                cookieProcess.Add(cookie);
            }
            else // иначе обновляем
            {
                // копируем обратно идентификатор объекта
                cookie.Id = _id;
                // обновляем
                cookieProcess.Update(cookie);
            }
            // и закрываем форму
            Close();
        }

        public void Load(CookieDto cookie)
        {
            // если объект не существует или его тип не в списке допустимых, выходим
            if (cookie == null || !Categories.Contains(cookie.Category) || !Statuses.Contains(cookie.Status))
            {
                return;
            }
            // сохраняем id печенья 
            _id = cookie.Id;
            // заполняем визуальные компоненты для отображения данных
            tbName.Text = cookie.Name;
            
            tbOrderDate.Text = cookie.OrderDate.ToString();
            if (cookie.SaleDate.HasValue)
            {
                tbSaleDate.Text = cookie.SaleDate.Value.ToString();
            }
            cbCategory.SelectedItem = cookie.Category;
            cbStatus.SelectedItem = cookie.Status;
        }
    }
}
