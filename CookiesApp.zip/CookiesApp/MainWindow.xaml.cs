﻿using CookiesApp.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace CookiesApp
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void BtnAdd_Click(object sender, RoutedEventArgs e)
        {
            AddCookieWindow window = new AddCookieWindow();
            window.ShowDialog();

            // Получаем список печенья и передаем его на отображение таблице
            dgCookie.ItemsSource = ProcessFactory.GetCookieProcess().GetList();
        }

        private void BtnRefresh_Click(object sender, RoutedEventArgs e)
        {
            // Получаем список печенья и передаем его на отображение таблице
            dgCookie.ItemsSource = ProcessFactory.GetCookieProcess().GetList();
        }

        private void BtnDelete_Click(object sender, RoutedEventArgs e)
        {
            // Получаем выделенную строку с объектом печенье 
            CookieDto item = dgCookie.SelectedItem as CookieDto;
            // если там не печенье или пользователь ничего не выбрал сообщаем об этом
            if (item == null)
            {
                MessageBox.Show("Выберите запись для удаления", "Удаление печенья");
            }
            // Просим подтвердить удаление
            MessageBoxResult result = MessageBox.Show("Удалить печенье " + item.Name + "?",
                "Удаление печенья", MessageBoxButton.YesNo, MessageBoxImage.Warning);
            // Если пользователь не подтвердил, выходим
            if (result != MessageBoxResult.Yes)
            {
                return;
            }
            // Если все проверки пройдены и подтверждение получено, удаляем печенье
            ProcessFactory.GetCookieProcess().Delete(item.Id);
            // И перезагружаем список печенья
            BtnRefresh_Click(sender, e);
        }

        private void BtnEdit_Click(object sender, RoutedEventArgs e)
        {
            // Получаем выделенную строку с объектом печенье 
            // если там не печенье  или пользователь ничего не выбрал сообщаем об этом
            if (!(dgCookie.SelectedItem is CookieDto item))
            {
                MessageBox.Show("Выберите запись для редактирования", "Редактирование");
                return;
            }
            // Создаем окно
            AddCookieWindow window = new AddCookieWindow();
            // отправляем объект на редактирование
            window.Load(item);
            // Отображаем окно с данными
            window.ShowDialog();
            // Перезагружаем список объектов
            BtnRefresh_Click(sender, e);
        }

        private void Exit_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }

        private void About_Click(object sender, RoutedEventArgs e)
        {
            //Справка
            MessageBox.Show("Автор программы Учёт продаж печенья: ДАНДА, \nДата релиза: 10.06.2024 г., \nEmail: danda@gmail.com", "Внимание!!");
        }

        private void BtnReg_Click(object sender, RoutedEventArgs e)
        {
            RegWindow regWindow = new RegWindow();
            regWindow.Show();
            Hide();
        }
    }
}
