﻿using System.Data.Entity;

namespace CookiesApp
{
    public class AppDBContext : DbContext
    {
        public AppDBContext() : base("DefaultConnection") { }
        public DbSet<User> Users { get; set; }
    }
}
