﻿using CookiesApp.Entities;
using System.Collections.Generic;

namespace CookiesApp.Interfaces
{
    /// <summary>
    /// Описание действий с объектов печенье в базе
    /// </summary>
    public interface ICookieDao
    {
        /// <summary>
        /// Получить печенье по id 
        /// </summary>
        /// <param name="id">id печенья</param>
        /// <returns>печенье</returns>
        Cookie Get(int id);

        /// <summary>
        /// Получить список всех товаров (печенья) в базе
        /// </summary>
        /// <returns>список всех товаров (печенья) в базе</returns>
        IList<Cookie> GetAll();

        /// <summary>
        /// Добавить товар - печенье в базу
        /// </summary>
        /// <param name="cookie">новый товар - печенье</param>
        void Add(Cookie cookie);

        /// <summary>
        /// Обновить товар - печенье
        /// </summary>
        /// <param name="cookie">обновленный товар-печенье</param>
        void Update(Cookie cookie);

        /// <summary>
        /// Удалить печенье
        /// </summary>
        /// <param name="id">id удаляемого печенья</param>
        void Delete(int id);
    }
}
