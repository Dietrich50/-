﻿using CookiesApp.Models;
using System.Collections.Generic;

namespace CookiesApp.Interfaces
{
    /// <summary>
    /// Декларация действий по работе с печеньем
    /// </summary>
    public interface ICookieProcess
    {
        /// <summary>
        /// Возвращает список печений
        /// </summary>
        /// <returns>спсок печений</returns>
        IList<CookieDto> GetList();

        /// <summary>
        /// Возвращает печенье по id 
        /// </summary>
        /// <param name="id">id печенья</param>
        /// <returns>Печенье</returns>
        CookieDto Get(int id);

        /// <summary>
        /// Добавляет печенье
        /// </summary>
        /// <param name="cookie"></param>
        void Add(CookieDto cookie);

        /// <summary>
        /// Обновляет данные о печенье
        /// </summary>
        /// <param name="cookie">Печенье, изменения о котором нужно сохранить</param>
        void Update(CookieDto cookie);

        /// <summary>
        /// Удаляет печенье
        /// </summary>
        /// <param name="id">id печенья, которое надо удалить</param>       
        void Delete(int id);
    }
}
