﻿using System.Collections.Generic;
using System.Linq;
using CookiesApp.Interfaces;

namespace CookiesApp.Models
{
    public class CookieProcess : ICookieProcess
    {
        private static readonly IDictionary<int, CookieDto> Cookies = new Dictionary<int, CookieDto>();

        public IList<CookieDto> GetList()
        {
            return new List<CookieDto>(Cookies.Values);
        }

        public CookieDto Get(int id)
        {
            return Cookies.ContainsKey(id) ? Cookies[id] : null;
        }

        public void Add(CookieDto cookie)
        {
            int max = Cookies.Keys.Count == 0 ? 1 : Cookies.Keys.Max(c => c) + 1;
            cookie.Id = max;
            Cookies.Add(max, cookie);
        }

        public void Update(CookieDto cookie)
        {
            if(Cookies.ContainsKey(cookie.Id))
                Cookies[cookie.Id] = cookie;
        }

        public void Delete(int id)
        {
            if (Cookies.ContainsKey(id))
                Cookies.Remove(id);
        }      
    }
}
