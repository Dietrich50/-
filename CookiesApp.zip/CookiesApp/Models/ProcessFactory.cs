﻿using CookiesApp.Interfaces;

namespace CookiesApp.Models
{
    /// <summary>
    /// Фабрика классов бизнес-логики
    /// </summary>
    public class ProcessFactory
    {
        /// <summary>
        /// Возвращает объект, реализующий <seealso cref="ICookieProcess"/>
        /// </summary>
        /// <returns></returns>
        public static ICookieProcess GetCookieProcess() { return new CookieProcessDb(); }
    }
}
