﻿using System.Collections.Generic;
using CookiesApp.Entities;

namespace CookiesApp.Models
{
    public class DtoConverter
    {
        public static CookieDto Convert(Cookie cookie)
        {
            if (cookie == null) 
                return null;
            var dto = new CookieDto();
            dto.Id = cookie.CookieId;
            dto.Name = cookie.Name; 
            dto.OrderDate = cookie.OrderDate;
            dto.SaleDate = cookie.SaleDate;
            dto.Category = cookie.Category;
            dto.Status = cookie.Status; 

            return dto;
        }

        public static Cookie Convert(CookieDto dto)
        {
            if (dto == null) return null;   
            var cookie = new Cookie();
            cookie.CookieId = dto.Id;
            cookie.Name = dto.Name;
            cookie.OrderDate = dto.OrderDate;
            cookie.SaleDate = dto.SaleDate;
            cookie.Category = dto.Category;
            cookie.Status = dto.Status;

            return cookie;
            
        }

        public static IList<CookieDto> Convert(IList<Cookie> cookies) 
        {
            if (cookies == null) return null;
            var cookieDtos = new List<CookieDto>();
            foreach (var cookie in cookies)
            {
                cookieDtos.Add(Convert(cookie));    
            }
            return cookieDtos;
        }
    }
}
