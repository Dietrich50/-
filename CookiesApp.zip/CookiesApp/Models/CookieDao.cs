﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using CookiesApp.Entities;
using CookiesApp.Interfaces;

namespace CookiesApp.Models
{
    public class CookieDao : ICookieDao
    {
        public Cookie Get(int id)
        {
            // Получаем объект подключения к базе
            using (var conn = GetConnection())
            {
                // открываем соединение
                conn.Open();

                // создаем sql команду
                using (var cmd =conn.CreateCommand())
                {
                    // создаем текст команды
                    cmd.CommandText = "SELECT CookieId, Name, OrderDate, SaleDate, Category, Status FROM Crackers WHERE CookieId = @Id";
                    // добавляем значение параметра
                    cmd.Parameters.AddWithValue("@Id", id);
                    // открывет SqlDataReader для чтения полученных в результате
                    // выполнения запроса данных
                    using (var dataReader = cmd.ExecuteReader())
                        return !dataReader.Read() ? null : LoadCookie(dataReader);
                }
            }
        }

        public IList<Cookie> GetAll()
        {
            var cookies = new List<Cookie>();
            using (var conn = GetConnection())
            {
                conn.Open();
                using(var cmd = conn.CreateCommand())
                {
                    cmd.CommandText = "SELECT CookieId, Name, OrderDate, SaleDate, Category, Status FROM Crackers";
                    using(var dataReader = cmd.ExecuteReader())
                    {
                        while (dataReader.Read())
                        {
                            cookies.Add(LoadCookie(dataReader));
                        }
                    }
                }
                return cookies;
            }
        }

        public void Add(Cookie cookie)
        {
            using (var conn = GetConnection())
            {
                conn.Open();
                using (var cmd = conn.CreateCommand())
                {
                    cmd.CommandText = "INSERT INTO Crackers (Name, OrderDate, SaleDate, Category, Status) VALUES (@Name, @OrderDate, @SaleDate, @Category, @Status)";
                    cmd.Parameters.AddWithValue("@Name", cookie.Name);
                    cmd.Parameters.AddWithValue("@OrderDate", cookie.OrderDate);
                    cmd.Parameters.AddWithValue("@Category", cookie.Category);
                    cmd.Parameters.AddWithValue("@Status", cookie.Status);

                    object saleDate = cookie.SaleDate.HasValue ? (object)cookie.SaleDate.Value : DBNull.Value;
                    cmd.Parameters.AddWithValue("@SaleDate", saleDate);
                    cmd.ExecuteNonQuery();
                }
            }
        }

        public void Update(Cookie cookie)
        {
            using (var conn = GetConnection()) 
            { 
                conn.Open();
                using (var cmd = conn.CreateCommand()) 
                {
                    cmd.CommandText = "UPDATE Crackers SET Name = @Name, OrderDate = @OrderDate, " +
                        "SaleDate = @SaleDate, Category = @Category, Status = @Status WHERE CookieId = @Id";
                    cmd.Parameters.AddWithValue("@Name", cookie.Name);
                    cmd.Parameters.AddWithValue("@OrderDate", cookie.OrderDate);
                    cmd.Parameters.AddWithValue("@Category", cookie.Category);
                    cmd.Parameters.AddWithValue("@Id", cookie.CookieId);
                    cmd.Parameters.AddWithValue("@Status", cookie.Status);

                    object saleDate = cookie.SaleDate.HasValue ? (object)cookie.SaleDate.Value : DBNull.Value;
                    cmd.Parameters.AddWithValue("@SaleDate", saleDate);
                    cmd.ExecuteNonQuery();
                }
            }
        }

        public void Delete(int id)
        {
            using(var conn = GetConnection()) 
            {
                conn.Open();
                using (var cmd = conn.CreateCommand()) 
                {
                    cmd.CommandText = "DELETE FROM Crackers WHERE CookieId = @Id";
                    cmd.Parameters.AddWithValue("@Id", id);
                    cmd.ExecuteNonQuery();
                }
            }
        }

        private static Cookie LoadCookie(SqlDataReader dataReader)
        {
            // Создаем пустой объект
            var cookie = new Cookie();
            // Заполняем поля объекта в соответствии с названиями полей
            // результирующего набора данных
            cookie.CookieId = dataReader.GetInt32(dataReader.GetOrdinal("CookieId"));
            cookie.OrderDate = Convert.ToInt32(dataReader["OrderDate"]);
            // Помните, что у нас поле SaleDate может иметь значение NULL? 
            // Следующие 3 строки корректно обрабатывают этот случай
            object saleDate = dataReader["SaleDate"];
            if (saleDate != DBNull.Value)
                cookie.SaleDate = Convert.ToInt32(saleDate);
            cookie.Name = dataReader.GetString(dataReader.GetOrdinal("Name"));
            cookie.Category = dataReader.GetString(dataReader.GetOrdinal("Category"));
            cookie.Status = dataReader.GetString(dataReader.GetOrdinal("Status"));
            return cookie;  
        }


        /// <summary>
        /// Возвращает строку подключения к базе
        /// </summary>
        /// <returns></returns>
        private static string GetConnectionString()
        {
            return ConfigurationManager.ConnectionStrings["Accounting"].ConnectionString; 
        }

        /// <summary>
        /// Возвращает объект подключения к базе
        /// </summary>
        /// <returns></returns>
        private static SqlConnection GetConnection()
        {
            return new SqlConnection(GetConnectionString());
        }
    }
}
