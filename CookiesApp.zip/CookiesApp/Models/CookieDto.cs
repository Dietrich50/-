﻿namespace CookiesApp.Models
{
    /// <summary>
    /// Класс - печенье
    /// </summary>
    public class CookieDto
    {
        /// <summary>
        /// id печенья 
        /// </summary>
        public int Id { get; set; }
        /// <summary>
        /// название печенья
        /// </summary>
        public string Name { get; set; }
        /// <summary>
        /// Дата заказа печенья
        /// </summary>
        public int OrderDate { get; set; }
        /// <summary>
        /// Дата продажи печенья
        /// </summary>
        public int? SaleDate { get; set; }
        /// <summary>
        /// Категория
        /// </summary>
        public string Category { get; set; }
        /// <summary>
        /// Статус
        /// </summary>
        public string Status { get; set; }
    }
}
