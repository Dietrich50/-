﻿using CookiesApp.Interfaces;
using System.Collections.Generic;

namespace CookiesApp.Models
{
    public class CookieProcessDb : ICookieProcess
    {
        private readonly ICookieDao _cookieDao;

        public CookieProcessDb()
        {
            _cookieDao = DaoFactory.GetCookieDao();
        }

        public IList<CookieDto> GetList()
        {
            return DtoConverter.Convert(_cookieDao.GetAll());
        }

        public CookieDto Get(int id)
        {
            return DtoConverter.Convert(_cookieDao.Get(id));
        }

        public void Add(CookieDto cookie)
        {
            _cookieDao.Add(DtoConverter.Convert(cookie));
        }

        public void Update(CookieDto cookie)
        {
            _cookieDao.Update(DtoConverter.Convert(cookie));
        }

        public void Delete(int id)
        {
            _cookieDao.Delete(id);
        }
    }
}
