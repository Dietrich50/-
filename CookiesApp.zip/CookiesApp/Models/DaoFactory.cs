﻿using CookiesApp.Interfaces;

namespace CookiesApp.Models
{
    public class DaoFactory
    {
        public static ICookieDao GetCookieDao() 
        {
            return new CookieDao();
        }
    }
}
