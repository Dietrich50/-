﻿namespace CookiesApp.Entities
{
    public class Cookie
    {
        public int CookieId;
        public string Name;
        public int OrderDate;
        public int? SaleDate;
        public string Category;
        public string Status;
    }
}
